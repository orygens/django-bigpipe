#!/usr/bin/python
# -*- coding: utf-8 -*-

# django-bipipe
# https://github.com/orygens/django-bigpipe

# Licensed under the MIT license:
# http://www.opensource.org/licenses/mit-license
# Copyright (c) 2011 Orygens contato@orygens.com

__version__ = (0, 0, 1)
